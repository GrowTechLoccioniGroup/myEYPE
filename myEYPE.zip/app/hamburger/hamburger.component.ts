import { Component } from '@angular/core';

@Component({
    selector: 'my-hamburger',
    templateUrl: 'app/hamburger/hamburger.component.html',
    styleUrls: ['app/hamburger/hamburger.component.css'],
})

export class HamburgerComponent {
}