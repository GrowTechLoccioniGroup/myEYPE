import { Component, OnInit } from '@angular/core';
import { ClassRecipe } from '../classes/class.recipe';
import { RecipeService } from '../recipe/recipe.service';

@Component({
    selector:'my-recipe',
    providers: [RecipeService],
    templateUrl: 'app/recipe/recipe.component.html',
    styleUrls: ['app/recipe/recipe.component.css']
})

export class RecipeComponent implements OnInit {
    private myRecipes: ClassRecipe[];

    constructor(private _recipeService: RecipeService) {
    }

    ngOnInit(){
        this.getRecipesItems();
    }

    private getRecipesItems(): void {
        this._recipeService.getRecipes().subscribe(
            (recipe) => {
                this.myRecipes = recipe.json();
            },
            error => console.log(error),
            () => console.log('Get all RECIPES complete!'));
    }
}