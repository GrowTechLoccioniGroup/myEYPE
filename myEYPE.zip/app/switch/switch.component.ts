import { Component } from '@angular/core';

@Component({
    selector: 'my-switch',
    templateUrl: 'app/switch/switch.component.html',
    styleUrls: ['app/switch/switch.component.css']
})

export class SwitchComponent {
}