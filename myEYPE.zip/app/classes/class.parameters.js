"use strict";
var ClassParameters = (function () {
    function ClassParameters() {
    }
    return ClassParameters;
}());
exports.ClassParameters = ClassParameters;
//# sourceMappingURL=class.parameters.js.map