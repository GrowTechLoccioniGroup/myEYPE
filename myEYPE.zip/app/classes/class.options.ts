export class ClassOptions {
    RGB: string;
    Light: boolean;
}