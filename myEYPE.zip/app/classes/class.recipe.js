"use strict";
var ClassRecipe = (function () {
    function ClassRecipe() {
    }
    return ClassRecipe;
}());
exports.ClassRecipe = ClassRecipe;
/* 3 post/put
    1- modifica parametri (put): tempAria, umid, pH
    2- put: mpdofica rgb e luci
    3- put/post: tende
*/ 
//# sourceMappingURL=class.recipe.js.map