"use strict";
var ClassOptions = (function () {
    function ClassOptions() {
    }
    return ClassOptions;
}());
exports.ClassOptions = ClassOptions;
//# sourceMappingURL=class.options.js.map