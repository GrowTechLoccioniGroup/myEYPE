export class ClassParameters {
    TimeStamp: Date;
    AirTemperature: number;
    WaterTemperature: number;
    Humidity: number;
    PH: number;
    Conductivity: number;
}