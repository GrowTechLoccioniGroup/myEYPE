import { Component } from '@angular/core';

@Component({
    selector: 'my-home',
    templateUrl: 'app/home/home.component.html',
    styleUrls: ['app/home/home.component.css'],
})

export class HomeComponent {
    public nomeImgEYPE: string;

   // this.nomeImgEYPE = '/app/ext/Insalata.png';

}