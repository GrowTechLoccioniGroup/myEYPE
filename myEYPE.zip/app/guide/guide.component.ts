import { Component } from '@angular/core';

@Component({
    selector: 'my-guide',
    templateUrl: 'app/guide/guide.component.html',
    styleUrls: ['app/guide/guide.component.css']
})

export class GuideComponent {
    
}