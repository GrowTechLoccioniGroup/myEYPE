import { Component } from '@angular/core';

@Component({
    selector: 'my-site',
    templateUrl: 'app/site/site.component.html',
    styleUrls: ['app/site/site.component.css']
})

export class SiteComponent {
    
}